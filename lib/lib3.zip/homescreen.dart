import 'package:flutter/material.dart';
import 'package:mobile_kokosan/koslist.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  double minHarga = 0;
  double maxHarga = 1000000;
  double selectedRating = 0;
  String selectedFilter = 'Kota';

  TextEditingController minHargaController = TextEditingController();
  TextEditingController maxHargaController = TextEditingController();

  bool showPriceFilter = false;
  bool showRatingFilter = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kokosan'),
        automaticallyImplyLeading: false,
        backgroundColor: Colors.teal, // Adjust to your theme color
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      selectedFilter = 'Harga';
                      showPriceFilter = !showPriceFilter;
                      showRatingFilter = false; // Close rating filter
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        selectedFilter == 'Harga' ? Colors.blue : Colors.grey,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.attach_money),
                      SizedBox(width: 8),
                      Text('Harga'),
                    ],
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      selectedFilter = 'Rating';
                      showRatingFilter = !showRatingFilter;
                      showPriceFilter = false; // Close price filter
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        selectedFilter == 'Rating' ? Colors.blue : Colors.grey,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  child: Text('Rating'),
                ),
              ],
            ),
            if (showRatingFilter)
              Container(
                height: 50,
                child: ElevatedButton(
                  onPressed: () {
                    // Handle rating selection logic
                  },
                  child: Text('Pilih Rating'),
                ),
              ),
            if (showPriceFilter)
              Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextFormField(
                        controller: minHargaController,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: 'Min Harga',
                          prefixText: 'Rp ',
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextFormField(
                        controller: maxHargaController,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: 'Max Harga',
                          prefixText: 'Rp ',
                        ),
                      ),
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      // Apply price range logic
                      setState(() {
                        minHarga = double.parse(minHargaController.text);
                        maxHarga = double.parse(maxHargaController.text);
                      });
                    },
                    child: Text('Terapkan'),
                  ),
                ],
              ),
            Expanded(
              child: KosList(),
            )
          ],
        ),
      ),
    );
  }
}
