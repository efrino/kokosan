import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mobile_kokosan/kosan.dart';
import 'package:mobile_kokosan/messagingscreen.dart';
import 'package:mobile_kokosan/profilpemilik.dart';

class HomePemilik extends StatelessWidget {
  final String email;
  final String pemilikID;

  HomePemilik(this.email, this.pemilikID);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Pemilik'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Kosan(pemilikID),
                ),
              );
            },
            child: Text('Lihat Kos Saya'),
          ),
          ElevatedButton(
            onPressed: () {
              // Navigasi ke halaman penambahan data kos
              _navigateToAddKos(context);
            },
            child: Text('Tambah Data Kos'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MessagingScreen(pemilikID),
                ),
              );
            },
            child: Text('Pesan'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ProfilPemilik(pemilikID),
                ),
              );
            },
            child: Text('Profil Saya'),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.message),
            label: 'Pesan',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
        onTap: (index) {
          switch (index) {
            case 0:
              // Navigasi ke halaman Home
              break;
            case 1:
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MessagingScreen(pemilikID),
                ),
              );
              break;
            case 2:
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ProfilPemilik(pemilikID),
                ),
              );
              break;
            default:
              break;
          }
        },
      ),
    );
  }

  // Fungsi untuk navigasi ke halaman penambahan data kos
  void _navigateToAddKos(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddKosPage(pemilikID),
      ),
    );
  }
}

class AddKosPage extends StatefulWidget {
  final String pemilikID;

  AddKosPage(this.pemilikID);

  @override
  _AddKosPageState createState() => _AddKosPageState();
}

class _AddKosPageState extends State<AddKosPage> {
  TextEditingController _namaController = TextEditingController();
  TextEditingController _alamatController = TextEditingController();
  TextEditingController _hargaController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tambah Data Kos'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _namaController,
              decoration: InputDecoration(labelText: 'Nama Kos'),
            ),
            TextField(
              controller: _alamatController,
              decoration: InputDecoration(labelText: 'Alamat Kos'),
            ),
            TextField(
              controller: _hargaController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Harga Kos'),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                // Panggil fungsi untuk menambahkan data kos ke Firestore
                _addKosData();
              },
              child: Text('Tambah Data Kos'),
            ),
          ],
        ),
      ),
    );
  }

  // Fungsi untuk menambahkan data kos ke Firestore
  void _addKosData() {
    String namaKos = _namaController.text.trim();
    String alamatKos = _alamatController.text.trim();
    int hargaKos = int.tryParse(_hargaController.text) ?? 0;

    // Validasi data kosong
    if (namaKos.isEmpty || alamatKos.isEmpty || hargaKos == 0) {
      // Tampilkan pesan error jika ada data yang kosong
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Semua field harus diisi dengan benar!'),
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    // Tambahkan data kos ke Firestore
    FirebaseFirestore.instance
        .collection('kokosan')
        .doc('kota')
        .collection('semarang')
        .add({
      'nama': namaKos,
      'alamat': alamatKos,
      'harga': hargaKos,
      'isPaid': false,
      'uid': widget.pemilikID,
    }).then((value) {
      // Tampilkan pesan sukses jika data berhasil ditambahkan
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Data Kos berhasil ditambahkan!'),
          duration: Duration(seconds: 2),
        ),
      );

      // Kembali ke halaman sebelumnya setelah menambahkan data
      Navigator.pop(context);
    }).catchError((error) {
      // Tampilkan pesan error jika terjadi kesalahan
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Terjadi kesalahan. Silakan coba lagi.'),
          duration: Duration(seconds: 2),
        ),
      );
    });
  }
}
