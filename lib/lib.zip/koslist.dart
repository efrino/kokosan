import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:mobile_kokosan/detailkos.dart';

class KosList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final User? user = FirebaseAuth.instance.currentUser;

    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('kokosan')
          .doc('kota')
          .collection('semarang')
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(
            child: CircularProgressIndicator(),
          );
        } else if (snapshot.hasError) {
          return Center(
            child: Text('Error: ${snapshot.error}'),
          );
        } else {
          final docs = snapshot.data?.docs ?? [];
          if (docs.isEmpty) {
            return Center(
              child: Text('No data available'),
            );
          }

          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (BuildContext context, int index) {
              final DocumentSnapshot document = docs[index];
              final Map<String, dynamic> data =
                  document.data() as Map<String, dynamic>;

              if (data.containsKey('pemilikID')) {
                final String nama = data['nama'] ?? 'No Title';
                final String alamat = data['alamat'] ?? 'No Location';
                final int harga = data['harga'] ?? 0;
                final bool isPaid = data['isPaid'] ?? false;
                final String pemilikID = data['pemilikID'] ?? '';

                if (!isPaid) {
                  return ListTile(
                    title: Text(nama),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(alamat),
                        Text('Harga: Rp.$harga,00'),
                        ElevatedButton(
                          onPressed: () async {
                            if (user != null && pemilikID != user.uid) {
                              final userSnapshot = await FirebaseFirestore
                                  .instance
                                  .collection('users')
                                  .doc(user.uid)
                                  .get();

                              if (userSnapshot.exists) {
                                final userData =
                                    userSnapshot.data() as Map<String, dynamic>;

                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => DetailKosScreen(
                                      kosData: {
                                        'nama': nama,
                                        'alamat': alamat,
                                        'harga': harga,
                                        'pemilikID': pemilikID,
                                        'documentId':
                                            document.id, // Add this line
                                        'userData': userData,
                                        // tambahkan properti lain sesuai kebutuhan
                                      },
                                    ),
                                  ),
                                );
                              } else {
                                print(
                                    "User pencari kos not found for uid: ${user.uid}");
                                // Tindakan lain yang sesuai jika data pemilikID tidak ditemukan
                              }
                            } else {
                              print(
                                  "Anda tidak bisa memesan produk Anda sendiri");
                            }
                          },
                          child: Text('Lihat Detail'),
                        ),
                      ],
                    ),
                  );
                } else {
                  // Kos sudah terjual, tetap tampilkan tetapi dengan tambahan penghuninya dengan memanggil userID bagian nama
                  return SizedBox.shrink();
                }
              } else {
                print("Document at index $index doesn't contain 'pemilikID'");
                return SizedBox.shrink();
              }
            },
          );
        }
      },
    );
  }
}
