import 'package:flutter/material.dart';

class ProfilPemilik extends StatelessWidget {
  final String pemilikID;

  ProfilPemilik(this.pemilikID);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profil Pemilik'),
      ),
      body: Center(
        child: Text('Halaman Profil Pemilik'),
      ),
    );
  }
}
