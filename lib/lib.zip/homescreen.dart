import 'package:flutter/material.dart';
import 'package:mobile_kokosan/koslist.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  double minHarga = 0;
  double maxHarga = 1000000;
  String selectedFilter = 'Kota';

  TextEditingController minHargaController = TextEditingController();
  TextEditingController maxHargaController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Kokosan'),
        automaticallyImplyLeading: false,
        backgroundColor: Colors.teal, // Sesuaikan dengan pilihan warna tema
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      selectedFilter = 'Harga';
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        selectedFilter == 'Harga' ? Colors.blue : Colors.grey,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons
                          .attach_money), // Tambahkan ikon uang pada tombol Harga
                      SizedBox(width: 8),
                      Text('Harga'),
                    ],
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      selectedFilter = 'Rating';
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        selectedFilter == 'Rating' ? Colors.blue : Colors.grey,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  child: Text('Rating'),
                ),
              ],
            ),
            if (selectedFilter == 'Rating')
              Container(
                height: 50,
                child: ElevatedButton(
                  onPressed: () {},
                  child: Text('Pilih Rating'),
                ),
              ),
            if (selectedFilter == 'Harga')
              Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextFormField(
                        controller: minHargaController,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: 'Min Harga',
                          prefixText:
                              'Rp ', // Tambahkan prefix untuk menunjukkan mata uang
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextFormField(
                        controller: maxHargaController,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: 'Max Harga',
                          prefixText:
                              'Rp ', // Tambahkan prefix untuk menunjukkan mata uang
                        ),
                      ),
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      // Tambahkan logika atau navigasi yang diinginkan saat tombol Harga diklik
                      setState(() {
                        minHarga = double.parse(minHargaController.text);
                        maxHarga = double.parse(maxHargaController.text);
                      });
                    },
                    child: Text('Terapkan'),
                  ),
                ],
              ),
            Expanded(
              child: KosList(),
            )
          ],
        ),
      ),
    );
  }
}
